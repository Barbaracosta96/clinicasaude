package com.clinicasaude;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ClinicasaudeApplication {

	public static void main(String[] args) {
		SpringApplication.run(ClinicasaudeApplication.class, args);
	}

}
