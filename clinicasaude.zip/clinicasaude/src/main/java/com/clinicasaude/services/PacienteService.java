package com.clinicasaude.services;

import com.clinicasaude.model.Paciente;
import com.clinicasaude.repositories.PacienteRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

import java.util.List;
import java.util.Optional;

@Service

public class PacienteService {
    @Autowired
    private PacienteRepository repository;

    public List <Paciente> findAll() {
        return repository.findAll();
    }

    public Paciente findId(Long id) {
        return repository.findById(id)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Paciente não encontrado!"));
    }

    public Paciente save(Paciente paciente) {
        return repository.save(paciente);
    }

    public Paciente update(Paciente pacienteAtualizada, Long id) {
        Optional<Paciente> pacienteOpt = repository.findById(id);
        if (pacienteOpt.isPresent()) {
            pacienteAtualizada.setId(id);
            return repository.save(pacienteAtualizada);
        } else {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, "Paciente não encontrado!");
        }
    }
    public void deletar(Long id) {
        repository.findById(id).map(cliente -> {
            repository.delete(cliente);
            return Void.TYPE;
        }).orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Paciente não encontrado!"));

    }
}
