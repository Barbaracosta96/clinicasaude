package com.clinicasaude.controller;

import com.clinicasaude.model.Paciente;
import com.clinicasaude.services.PacienteService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RequestMapping ("pacientes")
@RestController
public class PacientesController {
    @Autowired
    private PacienteService service;
    @GetMapping
    private ResponseEntity <?> findAll (){
        return ResponseEntity.ok(service.findAll());

    }
    @GetMapping ("{id}")
    private ResponseEntity <?> findId (@PathVariable("id")Long id) {
        return ResponseEntity.ok(service.findId(id));
    }
    @PostMapping
    private ResponseEntity <?> save (@RequestBody Paciente paciente) {
        return ResponseEntity.ok(service.save(paciente));
    }
    @PutMapping ("{id}")
    private ResponseEntity <?> save (@RequestBody Paciente paciente, @PathVariable("id")Long id) {
        return ResponseEntity.ok(service.update(paciente, id));
    }
    @DeleteMapping("{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void deletar(@PathVariable("id") Long id) {
        service.deletar(id);
    }
}
