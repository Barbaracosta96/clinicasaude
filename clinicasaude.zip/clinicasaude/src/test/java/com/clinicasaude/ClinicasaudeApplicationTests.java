package com.clinicasaude;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ClinicasaudeApplicationTests {

	@Test
	void contextLoads() {
	}

}
